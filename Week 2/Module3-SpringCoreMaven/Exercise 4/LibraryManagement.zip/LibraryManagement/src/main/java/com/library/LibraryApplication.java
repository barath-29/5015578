package com.library;

public class LibraryApplication {

	public static void main(String[] args){
        System.out.println("Configuration successful");
    }

}
